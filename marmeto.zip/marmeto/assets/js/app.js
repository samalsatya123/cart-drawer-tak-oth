let cart = [];

//get product
async function fetchCartData() {
    try {
    const response = await fetch('https://mocki.io/v1/539c3a78-25e4-4fc6-8b35-6f1550d2b7c6');
    if (!response.ok) throw new Error('Failed to fetch cart data');
    const data = await response.json();
    cart = data.map(item => ({ ...item, quantity: 1 }));
    renderCart();
    } catch (error) {
    console.error('Error fetching cart data:', error);
    }
}


//render cart
function renderCart() {
    const cartItemsContainer = document.getElementById('cart-items');
    const itemSummary = document.getElementById('item-summary');
    const totalSummary = document.getElementById('total-summary');
    const discountSummary = document.getElementById('discount-summary');
    const progressBar = document.getElementById('progress');
    const checkoutBtn = document.getElementById('checkout-btn');

    cartItemsContainer.innerHTML = '';
    let totalPrice = 0;
    let totalItems = 0;

    cart.forEach((item, index) => {
    if (item.available) {
        totalPrice += item.price * item.quantity;
        totalItems += item.quantity;

        const cartItem = document.createElement('div');
        cartItem.classList.add('cart-item');
        cartItem.innerHTML = `
        <img src="https://${item.featured_image}" class="cart-img" alt="${item.title}">
        <div class="cart-item-details">
            <div class="head-1-sec">
                <div class="heading-prod">${item.title}</div>
                <div><b>₹ ${(item.price * item.quantity) / 100}/-</b></div>
            </div>
            <div class="cart-item-controls">
            <span class="remove-btn" onclick="removeItem(${index})"><img src="./assets/img/icons8-delete-201.png"></span>
            <div class="id-ntm">
            <button class="qty-btn"  onclick="updateQuantity(${index}, -1)" ${item.quantity === 1 ? 'disabled' : ''}>-</button>
            <input class="input-qty" type="text" value="${item.quantity}" readonly>
            <span class="qty-btn" onclick="updateQuantity(${index}, 1)">+</span></div>
            
            </div>
        </div>
        `;
        cartItemsContainer.appendChild(cartItem);
    }
    });

    // Update summary
    itemSummary.innerHTML = `${totalItems} Items | <b>₹ ${totalPrice / 100}/-</b>`;
    totalSummary.innerHTML = `Total: <b>₹ ${totalPrice / 100}/-</b>`;
    discountSummary.innerHTML = `Discount on MRP: <b>₹ 0.00/-</b>`;


    // Enable/disable checkout button
    checkoutBtn.disabled = totalPrice === 0;
}
//update quantity
function updateQuantity(index, change) {
    cart[index].quantity += change;
    renderCart();
}
//remove item
function removeItem(index) {
    cart.splice(index, 1);
    renderCart();
}
fetchCartData();
// Get Elements
const openCartBtn = document.getElementById("open-cart-btn");
const closeCartBtn = document.getElementById("close-cart");
const cartDrawer = document.getElementById("cart-drawer");
const overlay = document.getElementById("overlay");

// Function to Open Cart
function openCart() {
  cartDrawer.classList.add("open");
  overlay.style.display = "block";
  document.body.style.overflow = "hidden";
}

// Function to Close Cart
function closeCart() {
  cartDrawer.classList.remove("open");
  overlay.style.display = "none";
  document.body.style.overflow = "auto";
}

// Event Listeners
openCartBtn.addEventListener("click", openCart);
closeCartBtn.addEventListener("click", closeCart);
overlay.addEventListener("click", closeCart);

// Close cart on pressing the 'Escape' key
document.addEventListener("keydown", (event) => {
  if (event.key === "Escape") {
    closeCart();
  }
});
